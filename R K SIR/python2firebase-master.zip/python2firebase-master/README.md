# python2firebase
An IoT project to sense data from sensors (e.g Moisture sensor, Smoke sensor etc..) (connected to arduino board) and push (via python script) to firebase realtime database and display in angular web application.
